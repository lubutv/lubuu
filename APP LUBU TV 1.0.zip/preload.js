const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('electronAPI', {
  updatePresence: (activityData) => handlePagePresenceUpdate(activityData),
  clearPresence: () => sendClearPresence('page-api-clear'),
});

const DEFAULT_LOGO_URL = 'https://webplayer.fuzzlab.shop/logow.png';
const PAGE_INSTANCE_ID = `${Date.now()}-${Math.random().toString(36).slice(2)}`;
let lastPresenceSignature = '';
let hadDetectedPlayback = false;
let observerStarted = false;
let lastProgressUpdateAt = 0;
let fastPollUntil = 0;
let adaptivePollTimer = null;
let mutationTickTimer = null;
let lastTimeUpdateTickAt = 0;
let lastPageActivity = null;
let lastPageActivityAt = 0;
let lastLiveChannelSwitchAt = 0;
let lastLivePlayableAt = 0;
let lastLiveClosedAt = 0;
let liveBridgeInjected = false;
let mediaAudioBridgeInjected = false;
let hostFullscreenBridgeInstalled = false;
let fallbackHostFullscreen = false;
let forceMovieZeroProgressUntil = 0;
let lastSentProgressTime = null;
let lastSentMediaKey = '';
let lastPageSessionKey = '';
let detectorGeneration = 0;
let livePresenceSequence = 0;
const lastPlayingAtByMediaType = new Map();
let lastVideoSample = {
  video: null,
  currentTime: 0,
  at: 0,
};
const PROGRESS_REFRESH_MS = 5000;
const FAST_POLL_MS = 250;
const ACTIVE_POLL_MS = 900;
const STABLE_POLL_MS = 2000;
const IDLE_POLL_MS = 8000;
const FAST_POLL_WINDOW_MS = 14000;
const LIVE_FALSE_ERROR_GRACE_MS = 12000;
const RECENT_PLAYING_GRACE_MS = 3500;
const LIVE_PLAYING_GRACE_MS = 20000;
const LIVE_SWITCH_STALE_SIGNAL_GRACE_MS = 9000;
const LIVE_PRESENCE_KEEPALIVE_MS = 60000;
const PAGE_UPDATE_BURST_DELAYS_MS = [0, 120, 300, 650, 1200, 2200, 3600, 5600, 8500, 12000];
const CONTROL_UPDATE_BURST_DELAYS_MS = [0, 60, 140, 300, 650, 1200, 2200];
const epgCacheByChannel = new Map();
const pageImageCacheByMediaType = new Map();

function cancelDetectorTimers() {
  if (adaptivePollTimer) {
    clearTimeout(adaptivePollTimer);
    adaptivePollTimer = null;
  }

  if (mutationTickTimer) {
    clearTimeout(mutationTickTimer);
    mutationTickTimer = null;
  }
}

function resetDetectorState(options = {}) {
  const { forgetPageActivity = false, cancelTimers = true } = options;

  detectorGeneration++;
  lastPresenceSignature = '';
  hadDetectedPlayback = false;
  lastProgressUpdateAt = 0;
  lastSentProgressTime = null;
  lastSentMediaKey = '';
  fastPollUntil = 0;
  lastVideoSample = {
    video: null,
    currentTime: 0,
    at: 0,
  };

  if (forgetPageActivity) {
    lastPageActivity = null;
    lastPageActivityAt = 0;
    lastPageSessionKey = '';
    lastLivePlayableAt = 0;
  }

  if (cancelTimers) {
    cancelDetectorTimers();
  }
}

function resetPresenceDeliveryState() {
  lastPresenceSignature = '';
  lastProgressUpdateAt = 0;
  lastSentProgressTime = null;
  lastSentMediaKey = '';
  lastVideoSample = {
    video: null,
    currentTime: 0,
    at: 0,
  };
}

function sendClearPresence(reason) {
  resetDetectorState({ forgetPageActivity: true });
  ipcRenderer.send('clear-presence', withMessageMeta({ reason }));
}

function withMessageMeta(payload) {
  return {
    ...(payload || {}),
    pageInstanceId: PAGE_INSTANCE_ID,
    clientSentAt: Date.now(),
    locationHref: window.location.href,
  };
}

function installLiveMainWorldBridge() {
  if (liveBridgeInjected || mediaTypeFromPath() !== 'live') {
    return;
  }

  const target = document.documentElement || document.head || document.body;

  if (!target) {
    return;
  }

  liveBridgeInjected = true;

  const script = document.createElement('script');
  script.textContent = `
(() => {
  if (window.__lubuLivePresenceBridgeInstalled) {
    return;
  }

  window.__lubuLivePresenceBridgeInstalled = true;
  const SOURCE = 'lubu-live-presence-bridge';

  const cleanText = (value) => String(value || '').replace(/\\s+/g, ' ').trim();
  const elementText = (root, selector) => {
    const node = selector ? root && root.querySelector(selector) : root;
    return cleanText(node && node.textContent);
  };
  const imageFromCard = (card) => {
    const image = card && card.querySelector('.channel-image');
    return image ? (image.getAttribute('data-src') || image.getAttribute('src') || '') : '';
  };
  const currentChannelFromPage = () => {
    try {
      if (typeof currentChannel !== 'undefined' && currentChannel) {
        return currentChannel;
      }
    } catch (err) {}

    return window.currentChannel || null;
  };
  const normaliseSearch = (value) => cleanText(value)
    .normalize('NFD')
    .replace(/[\\u0300-\\u036f]/g, '')
    .toLowerCase();
  const cleanEpgText = (value) => {
    const title = cleanText(value);
    const searchable = normaliseSearch(title);

    if (
      !title ||
      searchable.includes('carregando program') ||
      searchable.includes('programacao nao disponivel') ||
      searchable.includes('programacao indisponivel') ||
      searchable.includes('programa nao informado') ||
      searchable.includes('programa indisponivel')
    ) {
      return '';
    }

    return title;
  };
  const parseEpgRange = (value) => {
    const match = String(value || '').match(/(\\d{1,2}):(\\d{2})\\s*-\\s*(\\d{1,2}):(\\d{2})/);

    if (!match) {
      return null;
    }

    return {
      start: Number(match[1]) * 60 + Number(match[2]),
      end: Number(match[3]) * 60 + Number(match[4]),
    };
  };
  const isNowInsideEpgRange = (range) => {
    if (!range || !Number.isFinite(range.start) || !Number.isFinite(range.end)) {
      return false;
    }

    const now = new Date();
    let current = now.getHours() * 60 + now.getMinutes();
    let end = range.end;

    if (end <= range.start) {
      end += 24 * 60;
      if (current < range.start) {
        current += 24 * 60;
      }
    }

    return current >= range.start && current < end;
  };
  const currentEpgFromPage = () => {
    const items = [...document.querySelectorAll('#epgContent .epg-item')];

    for (const item of items) {
      const range = parseEpgRange(elementText(item, '.epg-time'));
      const title = cleanEpgText(elementText(item, '.epg-program'));

      if (title && isNowInsideEpgRange(range)) {
        return title;
      }
    }

    return cleanEpgText(elementText(document, '#epgContent .epg-item.current .epg-program'));
  };
  const playbackStatusFromPage = () => {
    const video = document.querySelector('video');
    const errorActive = document.querySelector('#playerError.active');

    if (errorActive) {
      return 'error';
    }

    if (video && (video.currentSrc || video.src) && (!video.paused || video.readyState >= 2)) {
      return 'playing';
    }

    return 'loading';
  };
  const isPlayerOpen = () => Boolean(document.querySelector('#playerSidebar.active'));
  const serialiseChannel = (channel, card) => {
    const fallbackName = elementText(card, '.channel-name') || elementText(document, '#playerTitle') || elementText(document, '#channelInfo');
    return {
      name: cleanText(channel && channel.name) || fallbackName,
      stream_icon: channel && channel.stream_icon ? channel.stream_icon : imageFromCard(card),
      stream_id: channel && channel.stream_id ? String(channel.stream_id) : '',
      epg_channel_id: channel && channel.epg_channel_id ? String(channel.epg_channel_id) : '',
      category_id: channel && channel.category_id ? String(channel.category_id) : '',
    };
  };
  const postPresence = (reason, channel, playbackStatus, card) => {
    if (!isPlayerOpen() && !card) {
      return;
    }

    const safeChannel = serialiseChannel(channel || (card ? null : currentChannelFromPage()), card);

    if (!safeChannel.name) {
      return;
    }

    window.postMessage({
      source: SOURCE,
      reason,
      playbackStatus: playbackStatus || 'playing',
      channel: safeChannel,
      title: safeChannel.name,
      image: safeChannel.stream_icon || '',
      epgTitle: currentEpgFromPage(),
    }, '*');
  };
  const wrapPlayChannel = () => {
    let original = null;

    try {
      original = typeof playChannel === 'function' ? playChannel : window.playChannel;
    } catch (err) {}

    if (typeof original !== 'function' || original.__lubuPresenceWrapped) {
      return;
    }

    const wrapped = function(channel, clickedCard) {
      postPresence('playChannel', channel, 'loading', clickedCard);
      return original.apply(this, arguments);
    };

    Object.defineProperty(wrapped, '__lubuPresenceWrapped', { value: true });

    try {
      playChannel = wrapped;
    } catch (err) {}

    window.playChannel = wrapped;
  };
  const wrapLoadEpg = () => {
    let original = null;

    try {
      original = typeof loadEPG === 'function' ? loadEPG : window.loadEPG;
    } catch (err) {}

    if (typeof original !== 'function' || original.__lubuPresenceWrapped) {
      return;
    }

    const wrapped = function(channel) {
      const result = original.apply(this, arguments);
      Promise.resolve(result).finally(() => {
        setTimeout(() => postPresence('epg-loaded', channel || currentChannelFromPage(), 'playing'), 80);
        setTimeout(() => postPresence('epg-loaded-late', channel || currentChannelFromPage(), 'playing'), 650);
      });
      return result;
    };

    Object.defineProperty(wrapped, '__lubuPresenceWrapped', { value: true });

    try {
      loadEPG = wrapped;
    } catch (err) {}

    window.loadEPG = wrapped;
  };
  const bindVideo = () => {
    const video = document.querySelector('video');

    if (!video || video.__lubuPresenceBridgeBound) {
      return;
    }

    video.__lubuPresenceBridgeBound = 'true';

    ['play', 'playing', 'timeupdate', 'loadeddata', 'canplay', 'canplaythrough'].forEach((eventName) => {
      video.addEventListener(eventName, () => postPresence('video:' + eventName, currentChannelFromPage(), 'playing'), { passive: true });
    });
    ['waiting', 'stalled', 'loadstart'].forEach((eventName) => {
      video.addEventListener(eventName, () => postPresence('video:' + eventName, currentChannelFromPage(), 'loading'), { passive: true });
    });
    video.addEventListener('error', () => postPresence('video:error', currentChannelFromPage(), 'error'), { passive: true });
  };
  const tick = () => {
    wrapPlayChannel();
    wrapLoadEpg();
    bindVideo();
  };
  const postEpgTick = () => {
    if (playbackStatusFromPage() === 'playing') {
      postPresence('epg-tick', currentChannelFromPage(), 'playing');
    }
  };

  document.addEventListener('click', (event) => {
    const card = event.target && event.target.closest ? event.target.closest('.channel-card') : null;

    if (card) {
      postPresence('card-click', null, 'loading', card);
    }
  }, true);

  tick();
  setInterval(tick, 750);
  setInterval(postEpgTick, 15000);
})();
`;
  target.appendChild(script);
  script.remove();
}

function handleLiveBridgeMessage(event) {
  const payload = event && event.data;

  if (!payload || payload.source !== 'lubu-live-presence-bridge' || mediaTypeFromPath() !== 'live') {
    return;
  }

  const channel = payload.channel || {};
  const reason = String(payload.reason || '');
  const title = normalizeTitle(channel.name || payload.title || textOf('#playerTitle') || textOf('#channelInfo'));
  const domLiveTitle = normalizeTitle(textOf('#playerTitle') || textOf('#channelInfo'));

  if (!title) {
    return;
  }

  if (
    domLiveTitle &&
    normalizeSearchText(domLiveTitle) !== normalizeSearchText(title) &&
    reason !== 'card-click' &&
    reason !== 'playChannel'
  ) {
    return;
  }

  let status = ['playing', 'loading', 'error'].includes(payload.playbackStatus)
    ? payload.playbackStatus
    : 'playing';
  const image = normalizeImageUrl(channel.stream_icon || payload.image) || getLiveThumbnail(title);
  const sessionKey = sessionKeyFor('live', title);
  const isDirectSwitchReason = reason === 'card-click' || reason === 'playChannel';
  const isDelayedLiveSignal = reason.startsWith('video:') || reason.startsWith('epg-');
  const payloadEpgTitle = cleanEpgTitle(payload.epgTitle);
  const epgCacheKey = normalizeSearchText(title);

  if (epgCacheKey && payloadEpgTitle && !isDirectSwitchReason) {
    epgCacheByChannel.set(epgCacheKey, payloadEpgTitle);
  }

  const isStaleLiveSignal = (
    isDelayedLiveSignal &&
    !isDirectSwitchReason &&
    lastPageSessionKey &&
    sessionKey !== lastPageSessionKey &&
    Date.now() - lastLiveChannelSwitchAt < LIVE_SWITCH_STALE_SIGNAL_GRACE_MS
  );

  if (!isDirectSwitchReason && Date.now() - lastLiveClosedAt < 3500) {
    return;
  }

  if (isStaleLiveSignal) {
    return;
  }

  if (status === 'loading' && sessionKey === lastPageSessionKey && wasLivePlayableRecently()) {
    status = 'playing';
  }

  const isNewSession = sessionKey !== lastPageSessionKey;
  const liveSequence = ++livePresenceSequence;

  if (isNewSession) {
    resetPresenceDeliveryState();
    lastPlayingAtByMediaType.delete('live');
    lastPageSessionKey = sessionKey;
    lastLivePlayableAt = 0;
  }

  detectorGeneration++;
  lastLiveChannelSwitchAt = Date.now();
  lastPageActivity = {
    state: title,
    largeImageKey: image,
    largeImageText: title,
  };
  lastPageActivityAt = Date.now();
  rememberPageImage(lastPageActivity);

  if (status === 'playing') {
    markLivePlayable();
  }

  const activity = {
    details: status === 'error' ? 'Falha ao carregar canal' : 'Canais ao Vivo',
    state: status === 'playing' ? buildLiveState(title) : title,
    largeImageKey: image,
    largeImageText: title,
    playbackStatus: status,
    mediaType: 'live',
    sessionKey,
    liveSequence,
    currentTime: 0,
    duration: 0,
    hasDuration: false,
    detectedBy: 'electron-preload-live-bridge',
  };

  sendPresenceActivity(activity, `bridge:${reason || 'live'}`);
  triggerFastPolling('bridge:live', 10000);
  queueDetectorBurst('bridge:live', [0, 60, 140, 300, 700, 1400, 2800, 5600], detectorGeneration);
}

function isMovieOrSeriesPath() {
  const mediaType = mediaTypeFromPath();
  return mediaType === 'movie' || mediaType === 'series';
}

function installMediaAudioBridge() {
  if (mediaAudioBridgeInjected || !isMovieOrSeriesPath()) {
    return;
  }

  const target = document.documentElement || document.head || document.body;

  if (!target) {
    return;
  }

  mediaAudioBridgeInjected = true;

  const script = document.createElement('script');
  script.textContent = `
(() => {
  if (window.__lubuMediaAudioBridgeInstalled) {
    return;
  }

  window.__lubuMediaAudioBridgeInstalled = true;
  const AUDIO_CHECK_MS = 900;
  const AUDIO_CHECK_LIMIT = 20;
  let restoredAudioSource = '';

  const normalize = (value) => String(value || '')
    .normalize('NFD')
    .replace(/[\\u0300-\\u036f]/g, '')
    .toLowerCase();
  const trackText = (track) => normalize([
    track && track.lang,
    track && track.language,
    track && track.label,
    track && track.name,
    track && track.groupId,
    track && track.id,
    track && track.attrs && track.attrs.LANGUAGE,
    track && track.attrs && track.attrs.NAME
  ].filter(Boolean).join(' '));
  const isPortugueseTrack = (track) => {
    const text = trackText(track);
    return /(^|[^a-z])(pt|por|pt-br|pt_br)([^a-z]|$)/.test(text) ||
      text.includes('portuguese') ||
      text.includes('portugues') ||
      text.includes('brasil') ||
      text.includes('brazil') ||
      text.includes('dublado');
  };
  const isEnglishTrack = (track) => {
    const text = trackText(track);
    return /(^|[^a-z])(en|eng|en-us|en_us)([^a-z]|$)/.test(text) ||
      text.includes('english') ||
      text.includes('ingles');
  };
  const isCommentaryTrack = (track) => {
    const text = trackText(track);
    return text.includes('commentary') ||
      text.includes('comentario') ||
      text.includes('comentarios') ||
      text.includes('description');
  };
  const choosePreferredAudioTrackIndex = (tracks) => {
    const list = Array.from(tracks || []);

    if (!list.length) {
      return -1;
    }

    let bestIndex = -1;
    let bestScore = -Infinity;

    list.forEach((track, index) => {
      if (!isPortugueseTrack(track) || isCommentaryTrack(track)) {
        return;
      }

      let score = 100;

      if (track && track.default) score += 12;
      if (track && track.enabled) score += 4;
      if (!isEnglishTrack(track)) score += 2;
      if (index === 0) score += 1;

      if (score > bestScore) {
        bestScore = score;
        bestIndex = index;
      }
    });

    return bestIndex;
  };
  const shouldRestoreAudibleState = (video) => {
    const sourceKey = video && (video.currentSrc || video.src || 'pending-media');

    if (!sourceKey) {
      return false;
    }

    if (sourceKey !== restoredAudioSource) {
      restoredAudioSource = sourceKey;
      return true;
    }

    return false;
  };
  const ensureAudibleVideo = (forceRestore = false) => {
    const video = document.querySelector('video');

    if (!video) {
      return;
    }

    const sourceKey = video.currentSrc || video.src || 'pending-media';
    const restoreAudio = forceRestore || shouldRestoreAudibleState(video);

    if (forceRestore && sourceKey) {
      restoredAudioSource = sourceKey;
    }

    if (restoreAudio) {
      const savedVolume = Number(localStorage.getItem('playerVolume'));

      if (!Number.isFinite(video.volume) || video.volume <= 0.02) {
        const nextVolume = Number.isFinite(savedVolume) && savedVolume > 0.02 ? savedVolume : 1;
        video.volume = Math.min(1, Math.max(0.15, nextVolume));
        localStorage.setItem('playerVolume', String(video.volume));
      }

      if (video.muted) {
        video.muted = false;
        localStorage.setItem('playerMuted', 'false');
      }
    }

    if (video.audioTracks && video.audioTracks.length > 0) {
      const targetIndex = choosePreferredAudioTrackIndex(video.audioTracks);
      if (targetIndex >= 0) {
        Array.from(video.audioTracks).forEach((track, index) => {
          track.enabled = index === targetIndex;
        });
      }
    }

    const volumeSlider = document.getElementById('volumeSlider');
    const muteBtn = document.getElementById('muteBtn');

    if (restoreAudio && volumeSlider) {
      volumeSlider.value = String(Math.round(video.volume * 100));
    }

    if (restoreAudio && muteBtn) {
      if (video.volume < 0.5) {
        muteBtn.innerHTML = '<i class="fas fa-volume-down"></i>';
      } else {
        muteBtn.innerHTML = '<i class="fas fa-volume-up"></i>';
      }
    }
  };
  const wireVideoAudio = () => {
    const video = document.querySelector('video');

    if (!video || video.__lubuAudioBridgeBound) {
      return;
    }

    video.__lubuAudioBridgeBound = 'true';
    ['loadstart', 'loadedmetadata', 'loadeddata', 'canplay', 'play', 'playing'].forEach((eventName) => {
      video.addEventListener(eventName, () => ensureAudibleVideo(false), { passive: true });
    });
    setTimeout(() => ensureAudibleVideo(true), 0);
  };
  const selectHlsAudioTrack = (hls) => {
    if (!hls || !Array.isArray(hls.audioTracks) || !hls.audioTracks.length) {
      return;
    }

    const targetIndex = choosePreferredAudioTrackIndex(hls.audioTracks);

    if (targetIndex >= 0 && hls.audioTrack !== targetIndex) {
      hls.audioTrack = targetIndex;
    }

    ensureAudibleVideo();
  };
  const wireHlsInstance = (hls) => {
    if (!hls || hls.__lubuAudioBridgeBound) {
      return hls;
    }

    hls.__lubuAudioBridgeBound = true;
    const events = window.Hls && window.Hls.Events ? window.Hls.Events : {};
    const bind = (eventName) => {
      if (eventName && typeof hls.on === 'function') {
        hls.on(eventName, () => {
          setTimeout(() => selectHlsAudioTrack(hls), 0);
          setTimeout(() => selectHlsAudioTrack(hls), 250);
        });
      }
    };

    bind(events.MANIFEST_PARSED);
    bind(events.AUDIO_TRACKS_UPDATED);
    bind(events.LEVEL_LOADED);
    bind(events.MEDIA_ATTACHED);

    for (let attempt = 0; attempt < AUDIO_CHECK_LIMIT; attempt += 1) {
      setTimeout(() => selectHlsAudioTrack(hls), attempt * AUDIO_CHECK_MS);
    }

    return hls;
  };
  const wrapHlsConstructor = (OriginalHls) => {
    if (typeof OriginalHls !== 'function' || OriginalHls.__lubuAudioWrapped) {
      return OriginalHls;
    }

    const WrappedHls = function(...args) {
      const instance = Reflect.construct(OriginalHls, args, OriginalHls);
      setTimeout(() => wireHlsInstance(instance), 0);
      return instance;
    };

    Object.setPrototypeOf(WrappedHls, OriginalHls);
    WrappedHls.prototype = OriginalHls.prototype;
    Object.defineProperty(WrappedHls, '__lubuAudioWrapped', { value: true });
    return WrappedHls;
  };
  const installHlsWrapper = () => {
    const descriptor = Object.getOwnPropertyDescriptor(window, 'Hls');

    if (descriptor && descriptor.get && descriptor.set && window.Hls && window.Hls.__lubuAudioWrapped) {
      return;
    }

    let currentHls = wrapHlsConstructor(window.Hls);

    try {
      Object.defineProperty(window, 'Hls', {
        configurable: true,
        get() {
          return currentHls;
        },
        set(value) {
          currentHls = wrapHlsConstructor(value);
        },
      });
    } catch (err) {
      if (currentHls) {
        window.Hls = currentHls;
      }
    }
  };

  installHlsWrapper();
  wireVideoAudio();
  ensureAudibleVideo();
  document.addEventListener('click', () => setTimeout(ensureAudibleVideo, 80), true);
  setInterval(() => {
    installHlsWrapper();
    wireVideoAudio();
    ensureAudibleVideo();
  }, 1500);
})();
`;
  target.appendChild(script);
  script.remove();
}

function textOf(selector) {
  const element = document.querySelector(selector);
  return element ? element.textContent.replace(/\s+/g, ' ').trim() : '';
}

function setHostFullscreen(active, reason) {
  fallbackHostFullscreen = Boolean(active);
  ipcRenderer.send('set-host-fullscreen', withMessageMeta({
    active: fallbackHostFullscreen,
    reason,
  }));

  const fullscreenIcon = document.getElementById('fullscreenIcon');
  if (fullscreenIcon) {
    fullscreenIcon.classList.toggle('fa-expand', !fallbackHostFullscreen);
    fullscreenIcon.classList.toggle('fa-compress', fallbackHostFullscreen);
  }
}

function installHostFullscreenBridge() {
  if (hostFullscreenBridgeInstalled) {
    return;
  }

  hostFullscreenBridgeInstalled = true;

  const originalRequestFullscreen = Element.prototype.requestFullscreen;
  if (typeof originalRequestFullscreen === 'function') {
    Element.prototype.requestFullscreen = function requestFullscreenWithHostFallback(...args) {
      if (fallbackHostFullscreen && !document.fullscreenElement) {
        setHostFullscreen(false, 'request-toggle-off');
        return Promise.resolve();
      }

      setHostFullscreen(true, 'request');
      const result = originalRequestFullscreen.apply(this, args);

      if (result && typeof result.catch === 'function') {
        result.catch(() => setHostFullscreen(true, 'request-failed'));
      }

      return result;
    };
  }

  const originalExitFullscreen = Document.prototype.exitFullscreen;
  if (typeof originalExitFullscreen === 'function') {
    Document.prototype.exitFullscreen = function exitFullscreenWithHostFallback(...args) {
      setHostFullscreen(false, 'exit');

      if (!document.fullscreenElement) {
        return Promise.resolve();
      }

      return originalExitFullscreen.apply(this, args);
    };
  }

  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape' && fallbackHostFullscreen && !document.fullscreenElement) {
      setHostFullscreen(false, 'escape');
    }
  }, true);

  window.addEventListener('pagehide', () => setHostFullscreen(false, 'pagehide'));
  window.addEventListener('beforeunload', () => setHostFullscreen(false, 'beforeunload'));
}

function isVisible(element) {
  if (!element) {
    return false;
  }

  const style = window.getComputedStyle(element);
  return style.display !== 'none' && style.visibility !== 'hidden' && style.opacity !== '0';
}

function isActiveSelector(selector) {
  const element = document.querySelector(selector);
  return !!element && element.classList.contains('active') && isVisible(element);
}

function mediaTypeFromPath() {
  const path = window.location.pathname.toLowerCase();

  if (path.includes('live')) {
    return 'live';
  }

  if (path.includes('movies')) {
    return 'movie';
  }

  if (path.includes('series')) {
    return 'series';
  }

  return '';
}

function isMediaPath() {
  return Boolean(mediaTypeFromPath());
}

function rewriteKnownProviderImageUrl(url) {
  const host = url.hostname.toLowerCase();
  const path = url.pathname.replace(/^\/+/, '/');

  if (host === '38.46.143.152' && path.startsWith('/static/logos/canais/')) {
    return `https://www.acstatic.co/logos/canais/${path.slice('/static/logos/canais/'.length)}${url.search}`;
  }

  if (host === 'file.gstaticontent.com' && path.startsWith('/t/p/')) {
    return `https://image.tmdb.org${path}${url.search}`;
  }

  return url.href;
}

function normalizeImageUrl(value) {
  const image = String(value || '').trim();

  if (!image || image.startsWith('data:')) {
    return '';
  }

  if (image.includes('via.placeholder.com')) {
    return '';
  }

  try {
    return rewriteKnownProviderImageUrl(new URL(image, window.location.href));
  } catch (err) {
    return image;
  }
}

function rememberPageImage(activityData) {
  const mediaType = mediaTypeFromPath();
  const image = normalizeImageUrl(activityData && activityData.largeImageKey);

  if (mediaType && image && image !== DEFAULT_LOGO_URL) {
    pageImageCacheByMediaType.set(mediaType, image);
  }
}

function getRecentPageActivity(mediaType, maxAgeMs = 7000) {
  if (!lastPageActivity || mediaTypeFromPath() !== mediaType) {
    return null;
  }

  return Date.now() - lastPageActivityAt <= maxAgeMs ? lastPageActivity : null;
}

function markMediaPlaying(mediaType) {
  if (mediaType) {
    lastPlayingAtByMediaType.set(mediaType, Date.now());
  }
}

function markLivePlayable() {
  lastLivePlayableAt = Date.now();
  markMediaPlaying('live');
}

function wasRecentlyPlaying(mediaType, maxAgeMs = RECENT_PLAYING_GRACE_MS) {
  const lastPlayingAt = lastPlayingAtByMediaType.get(mediaType) || 0;
  return Date.now() - lastPlayingAt <= maxAgeMs;
}

function wasLivePlayableRecently(maxAgeMs = LIVE_PLAYING_GRACE_MS) {
  return Date.now() - lastLivePlayableAt <= maxAgeMs;
}

function sessionKeyFor(mediaType, title) {
  return `${mediaType}:${normalizeSearchText(title)}`;
}

function titleFromPageActivity(activityData) {
  return normalizeTitle(activityData && activityData.state);
}

function imageFromElement(element) {
  if (!element) {
    return '';
  }

  const attrs = ['data-episode-thumb', 'data-src', 'src', 'poster'];

  for (const attr of attrs) {
    const image = normalizeImageUrl(element.getAttribute(attr));
    if (image) {
      return image;
    }
  }

  return '';
}

function imageFromSelector(selector) {
  return imageFromElement(document.querySelector(selector));
}

function imageFromBackground(selector) {
  const element = document.querySelector(selector);

  if (!element) {
    return '';
  }

  const backgroundImage = window.getComputedStyle(element).backgroundImage;
  const match = String(backgroundImage || '').match(/url\(["']?(.+?)["']?\)/);
  return match ? normalizeImageUrl(match[1]) : '';
}

function imageFromMatchingCard(cardSelector, titleSelector, title, imageSelector) {
  const targetTitle = normalizeSearchText(title);

  if (!targetTitle) {
    return '';
  }

  for (const card of document.querySelectorAll(cardSelector)) {
    const cardTitle = normalizeSearchText(getElementText(card, titleSelector));

    if (cardTitle && (cardTitle === targetTitle || targetTitle.includes(cardTitle) || cardTitle.includes(targetTitle))) {
      const image = imageFromElement(card.querySelector(imageSelector));
      if (image) {
        return image;
      }
    }
  }

  return '';
}

function fallbackImageFor(mediaType) {
  return pageImageCacheByMediaType.get(mediaType) || DEFAULT_LOGO_URL;
}

function sampleVideoProgress(video, currentTime) {
  const now = Date.now();
  const sameVideo = lastVideoSample.video === video;
  const elapsedMs = now - lastVideoSample.at;
  const movedForward = currentTime - lastVideoSample.currentTime;
  const isAdvancing = sameVideo && elapsedMs > 120 && elapsedMs < 3500 && movedForward > 0.18;

  lastVideoSample = {
    video,
    currentTime,
    at: now,
  };

  return isAdvancing;
}

function getPrimaryVideo() {
  const videos = [...document.querySelectorAll('video')];
  return videos.find((video) => {
    const hasSource = Boolean(video.currentSrc || video.src);
    return hasSource || video.readyState > 0 || video.networkState === 2;
  }) || videos[0] || null;
}

function hasActiveVideo() {
  const video = getPrimaryVideo();

  if (!video) {
    return false;
  }

  const hasSource = Boolean(video.currentSrc || video.src);
  const hasProgress = Number.isFinite(video.currentTime) && video.currentTime > 0;
  return hasSource && (!video.paused || hasProgress || video.readyState >= 2);
}

function getPlaybackStatus(playerActive, mediaType = '') {
  const video = getPrimaryVideo();
  const isLive = mediaType === 'live';
  const playerErrorActive = isActiveSelector('#playerError');

  if (!video) {
    if (playerErrorActive) {
      if (isLive && Date.now() - lastLiveChannelSwitchAt < LIVE_FALSE_ERROR_GRACE_MS) {
        return 'loading';
      }

      return 'error';
    }

    return playerActive ? 'loading' : 'idle';
  }

  const hasSource = Boolean(video.currentSrc || video.src);
  const currentTime = Number.isFinite(video.currentTime) ? video.currentTime : 0;
  const hasProgress = currentTime > 0.35;
  const isAdvancing = sampleVideoProgress(video, currentTime);
  const liveHasPlaybackSignal = isLive && hasSource && (
    !video.paused ||
    isAdvancing ||
    wasLivePlayableRecently()
  );

  if (playerErrorActive && (!isLive || Date.now() - lastLiveChannelSwitchAt >= LIVE_FALSE_ERROR_GRACE_MS)) {
    return 'error';
  }

  if (hasSource && video.ended) {
    return 'ended';
  }

  if ((isLive && liveHasPlaybackSignal) || (hasSource && (!video.paused || isAdvancing))) {
    markMediaPlaying(mediaType);
    return 'playing';
  }

  if (isLive && wasRecentlyPlaying(mediaType)) {
    return 'playing';
  }

  if (hasSource && video.paused && (hasProgress || video.readyState >= 2)) {
    if (!hasProgress && playerActive) {
      return 'loading';
    }

    return 'paused';
  }

  if (playerErrorActive) {
    if (isLive && Date.now() - lastLiveChannelSwitchAt < LIVE_FALSE_ERROR_GRACE_MS) {
      return 'loading';
    }

    if (wasRecentlyPlaying(mediaType)) {
      return 'playing';
    }

    return 'error';
  }

  if (isActiveSelector('#playerLoading') || playerActive || hasSource || video.networkState === 2) {
    return 'loading';
  }

  return 'idle';
}

function getVideoTiming() {
  const video = getPrimaryVideo();

  if (!video) {
    return {
      currentTime: 0,
      duration: 0,
      hasDuration: false,
    };
  }

  const currentTime = Number.isFinite(video.currentTime) ? Math.max(0, video.currentTime) : 0;
  const duration = Number.isFinite(video.duration) && video.duration > 0 ? video.duration : 0;

  return {
    currentTime: mediaTypeFromPath() === 'movie' && Date.now() < forceMovieZeroProgressUntil ? 0 : currentTime,
    duration,
    hasDuration: duration > 0,
  };
}

function formatTime(totalSeconds) {
  const seconds = Math.max(0, Math.floor(Number(totalSeconds) || 0));
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const remainingSeconds = seconds % 60;

  if (hours > 0) {
    return `${hours}:${String(minutes).padStart(2, '0')}:${String(remainingSeconds).padStart(2, '0')}`;
  }

  return `${minutes}:${String(remainingSeconds).padStart(2, '0')}`;
}

function normalizeTitle(value) {
  const title = String(value || '').replace(/\s+/g, ' ').trim();

  if (!title || title === 'Selecione um canal' || title === 'Episodio' || title === 'Episódio') {
    return '';
  }

  return title;
}

function normalizeSearchText(value) {
  return String(value || '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase();
}

function getElementText(element, selector) {
  const target = selector ? element.querySelector(selector) : element;
  return target ? target.textContent.replace(/\s+/g, ' ').trim() : '';
}

function cleanEpgTitle(value) {
  const title = normalizeTitle(value);
  const searchable = normalizeSearchText(title);

  if (
    !title ||
    searchable.includes('carregando program') ||
    searchable.includes('programacao nao disponivel') ||
    searchable.includes('programa nao informado') ||
    searchable.includes('programacao indisponivel') ||
    (searchable.includes('program') && searchable.includes('disponivel')) ||
    (searchable.includes('programa') && searchable.includes('informado'))
  ) {
    return '';
  }

  return title;
}

function isUnavailableEpgText(value) {
  const searchable = normalizeSearchText(value);
  return (
    searchable.includes('programacao nao disponivel') ||
    searchable.includes('programacao indisponivel') ||
    (searchable.includes('program') && searchable.includes('disponivel'))
  );
}

function parseEpgRange(value) {
  const match = String(value || '').match(/(\d{1,2}):(\d{2})\s*-\s*(\d{1,2}):(\d{2})/);

  if (!match) {
    return null;
  }

  const start = Number(match[1]) * 60 + Number(match[2]);
  const end = Number(match[3]) * 60 + Number(match[4]);

  if (!Number.isFinite(start) || !Number.isFinite(end)) {
    return null;
  }

  return { start, end };
}

function isNowInsideEpgRange(range) {
  const now = new Date();
  let current = now.getHours() * 60 + now.getMinutes();
  let end = range.end;

  if (end <= range.start) {
    end += 24 * 60;
    if (current < range.start) {
      current += 24 * 60;
    }
  }

  return current >= range.start && current < end;
}

function getCurrentEpgTitle(channelTitle) {
  const cacheKey = normalizeSearchText(channelTitle);
  const epgContentText = textOf('#epgContent');

  if (Date.now() - lastLiveChannelSwitchAt < 1200) {
    return cacheKey ? epgCacheByChannel.get(cacheKey) || '' : '';
  }

  if (cacheKey && isUnavailableEpgText(epgContentText)) {
    epgCacheByChannel.delete(cacheKey);
    return '';
  }

  const epgItems = [...document.querySelectorAll('#epgContent .epg-item')];

  for (const item of epgItems) {
    const range = parseEpgRange(getElementText(item, '.epg-time'));

    if (range && isNowInsideEpgRange(range)) {
      const title = cleanEpgTitle(getElementText(item, '.epg-program'));
      if (title) {
        if (cacheKey) {
          epgCacheByChannel.set(cacheKey, title);
        }
        return title;
      }
    }
  }

  const currentTitle = cleanEpgTitle(textOf('#epgContent .epg-item.current .epg-program'));

  if (currentTitle) {
    if (cacheKey) {
      epgCacheByChannel.set(cacheKey, currentTitle);
    }
    return currentTitle;
  }

  if (epgItems.length > 0) {
    if (cacheKey) {
      epgCacheByChannel.delete(cacheKey);
    }

    return '';
  }

  return cacheKey ? epgCacheByChannel.get(cacheKey) || '' : '';
}

function buildLiveState(channelTitle) {
  const epgTitle = getCurrentEpgTitle(channelTitle);
  return epgTitle ? `${channelTitle} - ${epgTitle}` : channelTitle;
}

function getLiveThumbnail(channelTitle) {
  const recentLiveActivity = getRecentPageActivity('live');
  const recentImage = normalizeImageUrl(recentLiveActivity && recentLiveActivity.largeImageKey);

  return (
    imageFromMatchingCard('.channel-card', '.channel-name', channelTitle, '.channel-image') ||
    imageFromSelector('.channel-card.playing .channel-image') ||
    recentImage ||
    pageImageCacheByMediaType.get('live') ||
    DEFAULT_LOGO_URL
  );
}

function getMovieThumbnail(title) {
  return (
    imageFromBackground('#modalBackdrop') ||
    imageFromMatchingCard('.movie-card', '.movie-title', title, '.movie-poster') ||
    fallbackImageFor('movie')
  );
}

function episodeNumbersFromTitle(title) {
  const searchable = normalizeSearchText(title);
  const seasonMatch = searchable.match(/temporada\s+(\d+)/);
  const episodeMatch = searchable.match(/epis\S*dio\s+(\d+)/);

  return {
    season: seasonMatch ? seasonMatch[1] : '',
    episode: episodeMatch ? episodeMatch[1] : '',
  };
}

function getSeriesEpisodeThumbnail(title) {
  const { season, episode } = episodeNumbersFromTitle(title);
  const selectors = season
    ? [`.episodes-list[data-season="${season}"] .episode-item`, '.episode-item']
    : ['.episode-item'];

  for (const selector of selectors) {
    for (const item of document.querySelectorAll(selector)) {
      const episodeNumberText = normalizeSearchText(getElementText(item, '.episode-number'));
      const matchesEpisode = !episode || new RegExp(`\\b${episode}\\b`).test(episodeNumberText);

      if (matchesEpisode) {
        const image = imageFromElement(item.querySelector('.episode-thumbnail'));
        if (image) {
          return image;
        }
      }
    }
  }

  return fallbackImageFor('series');
}

function statusDetails(status, labels) {
  if (status === 'paused') {
    return labels.paused;
  }

  if (status === 'loading') {
    return labels.loading;
  }

  if (status === 'error') {
    return labels.error;
  }

  if (status === 'ended') {
    return labels.ended;
  }

  return labels.playing;
}

function statusState(title, status, timing) {
  if (status === 'paused' && timing.hasDuration) {
    return `${title} - ${formatTime(timing.currentTime)} / ${formatTime(timing.duration)}`;
  }

  if (status === 'ended' && timing.hasDuration) {
    return `${title} - ${formatTime(timing.duration)} / ${formatTime(timing.duration)}`;
  }

  return title;
}

function sendPresenceActivity(activity, reason) {
  if (!activity) {
    return null;
  }

  const signature = JSON.stringify({
    details: activity.details,
    state: activity.state,
    largeImageKey: activity.largeImageKey,
    largeImageText: activity.largeImageText,
    playbackStatus: activity.playbackStatus,
  });
  const now = Date.now();
  const mediaKey = `${activity.mediaType || ''}|${activity.details || ''}|${activity.state || ''}`;
  const hasTimedProgress = (
    activity.playbackStatus === 'playing' &&
    activity.hasDuration &&
    (activity.mediaType === 'movie' || activity.mediaType === 'series')
  );
  const isLivePlaying = activity.mediaType === 'live' && activity.playbackStatus === 'playing';

  if (mediaKey !== lastSentMediaKey) {
    lastSentMediaKey = mediaKey;
    lastSentProgressTime = null;
    lastProgressUpdateAt = 0;
  }

  if (activity.playbackStatus === 'playing') {
    markMediaPlaying(activity.mediaType);
  }

  const reasonText = String(reason || '');
  const forceProgressRefresh = (
    reasonText.includes('seek') ||
    reasonText.includes('durationchange') ||
    reasonText.includes('click') ||
    reasonText.includes('manual-time') ||
    reasonText.includes('restart')
  );
  const expectedCurrentTime = lastSentProgressTime === null
    ? null
    : lastSentProgressTime + (now - lastProgressUpdateAt) / 1000;
  const progressJumped = hasTimedProgress && expectedCurrentTime !== null && (
    Math.abs(activity.currentTime - expectedCurrentTime) >= 2.25
  );
  const liveKeepAlive = isLivePlaying && now - lastProgressUpdateAt >= LIVE_PRESENCE_KEEPALIVE_MS;
  const shouldRefreshProgress = hasTimedProgress && (
    forceProgressRefresh ||
    progressJumped ||
    now - lastProgressUpdateAt >= PROGRESS_REFRESH_MS
  );

  if (signature !== lastPresenceSignature || shouldRefreshProgress || liveKeepAlive) {
    lastPresenceSignature = signature;
    if (hasTimedProgress || isLivePlaying) {
      lastProgressUpdateAt = now;
      if (hasTimedProgress) {
        lastSentProgressTime = activity.currentTime;
      }
    }
    hadDetectedPlayback = true;
    ipcRenderer.send('update-presence', withMessageMeta({ ...activity, reason }));
  }

  return activity;
}

function buildImmediatePageActivity(activityData) {
  const mediaType = mediaTypeFromPath();
  const timing = getVideoTiming();

  if (mediaType === 'live') {
    const title = titleFromPageActivity(activityData) || normalizeTitle(textOf('#playerTitle') || textOf('#channelInfo'));

    if (!title) {
      return null;
    }

    return {
      details: 'Canais ao Vivo',
      state: title,
      largeImageKey: getLiveThumbnail(title),
      largeImageText: title,
      playbackStatus: 'loading',
      mediaType: 'live',
      sessionKey: sessionKeyFor('live', title),
      liveSequence: ++livePresenceSequence,
      currentTime: 0,
      duration: 0,
      hasDuration: false,
      detectedBy: 'electron-preload-page-live',
    };
  }

  if (mediaType === 'movie') {
    const title = normalizeTitle(textOf('#playerMovieTitle') || titleFromPageActivity(activityData) || textOf('#modalTitle'));

    if (!title) {
      return null;
    }

    return {
      details: 'Carregando filme',
      state: title,
      largeImageKey: getMovieThumbnail(title),
      largeImageText: title,
      playbackStatus: 'loading',
      mediaType: 'movie',
      sessionKey: sessionKeyFor('movie', title),
      currentTime: timing.currentTime,
      duration: timing.duration,
      hasDuration: timing.hasDuration,
      detectedBy: 'electron-preload-page-movie',
    };
  }

  if (mediaType === 'series') {
    const title = normalizeTitle(textOf('#playerEpisodeTitle'));

    if (!title) {
      return null;
    }

    return {
      details: 'Carregando episodio',
      state: title,
      largeImageKey: getSeriesEpisodeThumbnail(title),
      largeImageText: title,
      playbackStatus: 'loading',
      mediaType: 'series',
      sessionKey: sessionKeyFor('series', title),
      currentTime: timing.currentTime,
      duration: timing.duration,
      hasDuration: timing.hasDuration,
      detectedBy: 'electron-preload-page-series',
    };
  }

  return null;
}

function handlePagePresenceUpdate(activityData) {
  lastPageActivity = activityData || {};
  lastPageActivityAt = Date.now();
  detectorGeneration++;
  rememberPageImage(lastPageActivity);

  if (!isMediaPath()) {
    ipcRenderer.send('update-presence', withMessageMeta(lastPageActivity));
    return;
  }

  const mediaType = mediaTypeFromPath();
  const immediateActivity = buildImmediatePageActivity(lastPageActivity);
  const nextSessionKey = immediateActivity && immediateActivity.sessionKey ? immediateActivity.sessionKey : '';
  const isNewSession = Boolean(nextSessionKey && nextSessionKey !== lastPageSessionKey);

  if (isNewSession) {
    resetPresenceDeliveryState();
    lastPlayingAtByMediaType.delete(mediaType);
    lastPageSessionKey = nextSessionKey;

    if (mediaType === 'live') {
      lastLivePlayableAt = 0;
    }
  }

  if (mediaType === 'live') {
    lastLiveChannelSwitchAt = Date.now();
  }

  if (mediaType === 'live' && !isNewSession && wasRecentlyPlaying('live') && hasActiveVideo()) {
    sendDetectedPresence('page:updatePresence:active');
  } else {
    sendPresenceActivity(immediateActivity, 'page:updatePresence:immediate');
  }

  triggerFastPolling('page:updatePresence');
  queueDetectorBurst('page:updatePresence', PAGE_UPDATE_BURST_DELAYS_MS, detectorGeneration);
}

function getActivityFromDom() {
  const path = window.location.pathname.toLowerCase();
  const timing = getVideoTiming();

  if (path.includes('live')) {
    const sidebarActive = isActiveSelector('#playerSidebar');
    const status = getPlaybackStatus(sidebarActive, 'live');
    const domTitle = normalizeTitle(
      textOf('#playerTitle') ||
      textOf('#channelInfo') ||
      textOf('.channel-card.playing .channel-name')
    );
    const recentLiveTitle = titleFromPageActivity(getRecentPageActivity('live'));
    const title = domTitle || recentLiveTitle;

    if (title && sidebarActive) {
      return {
        details: statusDetails(status, {
          playing: 'Canais ao Vivo',
          paused: 'Canal pausado',
          loading: 'Canais ao Vivo',
          error: 'Falha ao carregar canal',
          ended: 'Canal finalizado',
        }),
        state: buildLiveState(title),
        largeImageKey: getLiveThumbnail(title),
        largeImageText: title,
        playbackStatus: status,
        mediaType: 'live',
        sessionKey: sessionKeyFor('live', title),
        liveSequence: livePresenceSequence,
        currentTime: 0,
        duration: 0,
        hasDuration: false,
        detectedBy: 'electron-preload-live',
      };
    }
  }

  if (path.includes('movies')) {
    const playerActive = isActiveSelector('#fullscreenPlayer');
    const status = getPlaybackStatus(playerActive, 'movie');
    const title = normalizeTitle(textOf('#playerMovieTitle') || textOf('#modalTitle'));

    if (title && playerActive) {
      return {
        details: statusDetails(status, {
          playing: 'Assistindo a um Filme',
          paused: 'Filme pausado',
          loading: 'Carregando filme',
          error: 'Falha ao carregar filme',
          ended: 'Filme finalizado',
        }),
        state: statusState(title, status, timing),
        largeImageKey: getMovieThumbnail(title),
        largeImageText: title,
        playbackStatus: status,
        mediaType: 'movie',
        sessionKey: sessionKeyFor('movie', title),
        currentTime: timing.currentTime,
        duration: timing.duration,
        hasDuration: timing.hasDuration,
        detectedBy: 'electron-preload-movies',
      };
    }
  }

  if (path.includes('series')) {
    const playerActive = isActiveSelector('#fullscreenPlayer');
    const status = getPlaybackStatus(playerActive, 'series');
    const title = normalizeTitle(textOf('#playerEpisodeTitle'));

    if (title && playerActive) {
      const seriesName = title.split(' - Temporada ')[0] || 'Assistindo uma Serie';

      return {
        details: statusDetails(status, {
          playing: seriesName,
          paused: 'Episodio pausado',
          loading: 'Carregando episodio',
          error: 'Falha ao carregar episodio',
          ended: 'Episodio finalizado',
        }),
        state: statusState(title, status, timing),
        largeImageKey: getSeriesEpisodeThumbnail(title),
        largeImageText: title,
        playbackStatus: status,
        mediaType: 'series',
        sessionKey: sessionKeyFor('series', title),
        currentTime: timing.currentTime,
        duration: timing.duration,
        hasDuration: timing.hasDuration,
        detectedBy: 'electron-preload-series',
      };
    }
  }

  return null;
}

function sendDetectedPresence(reason) {
  const activity = getActivityFromDom();

  if (activity) {
    return sendPresenceActivity(activity, reason);
  }

  if (hadDetectedPlayback) {
    sendClearPresence('detector-no-activity');
  }

  return null;
}

function triggerFastPolling(reason, duration = FAST_POLL_WINDOW_MS) {
  fastPollUntil = Math.max(fastPollUntil, Date.now() + duration);
  scheduleAdaptivePoll(null, reason);
}

function getNextPollDelay(activity) {
  const now = Date.now();

  if (now < fastPollUntil) {
    return FAST_POLL_MS;
  }

  if (!activity) {
    return IDLE_POLL_MS;
  }

  if (activity.playbackStatus === 'loading') {
    return ACTIVE_POLL_MS;
  }

  if (activity.mediaType === 'live') {
    return STABLE_POLL_MS;
  }

  if (activity.playbackStatus === 'playing') {
    return STABLE_POLL_MS;
  }

  return ACTIVE_POLL_MS;
}

function scheduleAdaptivePoll(activity, reason) {
  if (adaptivePollTimer) {
    clearTimeout(adaptivePollTimer);
  }

  adaptivePollTimer = setTimeout(() => {
    adaptivePollTimer = null;
    runDetectorTick(reason || 'adaptive');
  }, getNextPollDelay(activity));
}

function runDetectorTick(reason) {
  installLiveMainWorldBridge();
  installMediaAudioBridge();
  bindVideoListeners();
  const activity = sendDetectedPresence(reason);
  scheduleAdaptivePoll(activity, 'adaptive');
}

function requestDetectorTick(reason, delay = 120) {
  if (mutationTickTimer) {
    clearTimeout(mutationTickTimer);
  }

  mutationTickTimer = setTimeout(() => {
    mutationTickTimer = null;
    runDetectorTick(reason);
  }, delay);
}

function queueDetectorBurst(reason, delays = PAGE_UPDATE_BURST_DELAYS_MS, generation = detectorGeneration) {
  delays.forEach((delay) => {
    setTimeout(() => {
      if (generation === detectorGeneration) {
        runDetectorTick(`${reason}:${delay}`);
      }
    }, delay);
  });
}

function handleVideoEvent(eventName) {
  const now = Date.now();
  const mediaType = mediaTypeFromPath();

  if (
    mediaType === 'live' &&
    ['play', 'playing', 'timeupdate', 'canplay', 'canplaythrough'].includes(eventName)
  ) {
    const video = getPrimaryVideo();
    if (video && (video.currentSrc || video.src || video.readyState >= 2)) {
      markLivePlayable();
    }
  }

  if (eventName === 'timeupdate' && now - lastTimeUpdateTickAt < 800) {
    return;
  }

  if (eventName === 'timeupdate') {
    lastTimeUpdateTickAt = now;
  }

  if (['play', 'playing', 'loadeddata', 'loadedmetadata', 'durationchange', 'seeking', 'seeked', 'waiting', 'stalled', 'canplay', 'canplaythrough', 'pause', 'emptied'].includes(eventName)) {
    triggerFastPolling(`video:${eventName}`);
  }

  runDetectorTick(`video:${eventName}`);
}

function isCloseControl(target) {
  const element = target && target.closest && target.closest('button, a, [onclick]');

  if (!element) {
    return false;
  }

  const onclick = String(element.getAttribute('onclick') || '').toLowerCase();
  const title = String(element.getAttribute('title') || '').toLowerCase();

  return (
    element.classList.contains('btn-close-player') ||
    onclick.includes('backtoseasons') ||
    onclick.includes('exitplayer') ||
    onclick.includes('closeplayer') ||
    title.includes('fechar')
  );
}

function verifyClosedPlayer() {
  const activity = getActivityFromDom();

  if (!activity) {
    sendClearPresence('player-closed');
    return;
  }

  sendPresenceActivity(activity, 'close-verify-active');
}

function isMediaControlTarget(target) {
  const element = target && target.closest && target.closest('button, a, input, [onclick], [role="button"], .control-btn');

  if (!element) {
    return false;
  }

  const text = normalizeSearchText([
    element.textContent,
    element.getAttribute('onclick'),
    element.getAttribute('title'),
    element.getAttribute('aria-label'),
    element.id,
    element.className,
  ].filter(Boolean).join(' '));

  return (
    text.includes('skip') ||
    text.includes('voltar') ||
    text.includes('avancar') ||
    text.includes('avançar') ||
    text.includes('retroced') ||
    text.includes('restart') ||
    text.includes('reiniciar') ||
    text.includes('progress') ||
    text.includes('10s') ||
    text.includes('10 s')
  );
}

function isMovieRestartControl(target) {
  const element = target && target.closest && target.closest('button, a, [onclick], [role="button"]');

  if (!element) {
    return false;
  }

  const text = normalizeSearchText([
    element.textContent,
    element.getAttribute('onclick'),
    element.getAttribute('title'),
    element.getAttribute('aria-label'),
    element.id,
    element.className,
  ].filter(Boolean).join(' '));

  return (
    text.includes('restartmovie') ||
    text.includes('btnrestartwatch') ||
    text.includes('reiniciar') ||
    text.includes('recomecar') ||
    text.includes('recomeçar') ||
    text.includes('do inicio') ||
    text.includes('do inÃ­cio')
  );
}

function forceControlPresenceRefresh(reason) {
  triggerFastPolling(reason, 9000);
  queueDetectorBurst(reason, CONTROL_UPDATE_BURST_DELAYS_MS, detectorGeneration);
}

function forceMovieRestartPresenceRefresh(reason) {
  triggerFastPolling(reason, 5000);
  queueDetectorBurst(reason, [0, 90, 240, 650, 1300], detectorGeneration);
}

function bindVideoListeners() {
  document.querySelectorAll('video').forEach((video) => {
    if (video.dataset.discordPresenceBound === 'true') {
      return;
    }

    video.dataset.discordPresenceBound = 'true';
    ['play', 'playing', 'loadeddata', 'loadedmetadata', 'durationchange', 'timeupdate', 'seeking', 'seeked', 'ratechange', 'waiting', 'stalled', 'canplay', 'canplaythrough', 'pause', 'ended', 'emptied'].forEach((eventName) => {
      video.addEventListener(eventName, () => handleVideoEvent(eventName), { passive: true });
    });
  });
}

function startPresenceDetector() {
  if (observerStarted) {
    return;
  }

  observerStarted = true;

  const tick = (reason) => {
    installLiveMainWorldBridge();
    installMediaAudioBridge();
    installHostFullscreenBridge();
    runDetectorTick(reason);
  };

  window.addEventListener('message', handleLiveBridgeMessage);
  window.addEventListener('DOMContentLoaded', () => tick('dom-ready'));
  window.addEventListener('load', () => tick('window-load'));
  window.addEventListener('beforeunload', () => sendClearPresence('beforeunload'));
  window.addEventListener('pagehide', () => sendClearPresence('pagehide'));
  document.addEventListener('click', (event) => {
    detectorGeneration++;

    if (isCloseControl(event.target)) {
      if (mediaTypeFromPath() === 'live') {
        lastLiveClosedAt = Date.now();
        sendClearPresence('live-close-click');
      }

      setTimeout(verifyClosedPlayer, 220);
      setTimeout(verifyClosedPlayer, 700);
    }

    const handledMovieRestart = mediaTypeFromPath() === 'movie' && isMovieRestartControl(event.target);

    if (handledMovieRestart) {
      forceMovieZeroProgressUntil = Date.now() + 4500;
      resetPresenceDeliveryState();
      forceMovieRestartPresenceRefresh('manual-time:movie-restart-zero');
    }

    if (!handledMovieRestart && isMediaControlTarget(event.target)) {
      forceControlPresenceRefresh('manual-time:control-click');
    }

    triggerFastPolling('click');
    queueDetectorBurst('click', [0, 80, 220, 450, 900, 1600, 3200, 5200], detectorGeneration);
  }, true);

  document.addEventListener('keydown', (event) => {
    if (['ArrowLeft', 'ArrowRight', 'Home', 'End', 'j', 'J', 'l', 'L'].includes(event.key)) {
      detectorGeneration++;
      forceControlPresenceRefresh(`manual-time:key:${event.key}`);
    }
  }, true);

  const observer = new MutationObserver(() => requestDetectorTick('mutation', 160));
  observer.observe(document.documentElement, {
    childList: true,
    subtree: true,
    characterData: true,
    attributes: true,
    attributeFilter: ['class', 'style', 'src'],
  });

  tick('startup');
}

startPresenceDetector();
